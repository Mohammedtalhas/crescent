$(document).ready(function()
{
	Insert_record();
	edit();
	update();
	get();
	app_edit();
	getUrlVars();
	$('#mop').on('change', function() {
      if ( this.value == 'cheque')
      {
        $("#myDIV").show();
      }
      else
      {
        $("#myDIV").hide();
      }
    });
	
	
	
})


function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=%20');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
     var ids = vars['id'];
	
	
	if(ids!=''){
		
		
			
			$.ajax(
				{
					url : 'get_loandetails.php',
					method : 'post',
					data :{ids:ids},
					dataType :"JSON",
					success:function(data){
					
						$('#Adhaarnumber').val(data.Adhaarnumber);
						$('#firstname').val(data.firstname);
						$('#lastname').val(data.lastname);
						$('#dateofbirth').val(data.dateofbirth);
						$('#number').val(data.mobilenumber);
						$('#address').val(data.addrss);
						$('#town').val(data.town);
						$('#adhaar').val(data.Adhaarnumber);
						/*$.ajax(
						{
							url : 'table_edu.php',
							method : 'post',
							data :{ids:ids},
							success:function(data){
								data= $.parseJSON(data);
								if(data.status=='success'){
									$('#table').html(data.html);
								} else{
									$('#table').html(data.html);
								}
							}
						});*/
						
					}
					
			
		});
			
			
	
}
}
function get(){
	$(document).on('click','#go',function(){
		var ids =$('#input').val();
		
		if(ids != ''){
			$.ajax(
				{
					url : 'get_loandetails.php',
					method : 'post',
					data :{ids:ids},
					dataType :"JSON",
					success:function(data){
						$('#Adhaarnumber').val(data.Adhaarnumber);
						$('#firstname').val(data.firstname);
						$('#lastname').val(data.lastname);
						$('#dateofbirth').val(data.dateofbirth);
						$('#number').val(data.mobilenumber);
						$('#address').val(data.addrss);
						$('#town').val(data.town);
						$('#adhaar').val(data.Adhaarnumber);
						window.open('jewelloanold.php?id= '+data.Adhaarnumber,'_self');
						/*$.ajax(
							{
								url : 'table_edu.php',
								method : 'post',
								data :{ids:ids},
								success:function(data){
									data=$.parseJSON(data);
									
									if(data.status=='success'){
										$('#table').html(data.html);
										
									} else{
									$('#table').html(data.html);
								}
								}
							});*/
						
					}
					
			
		});
		
	}
});
}
function Insert_record()
{	
	$('#insert_det').submit(function(e)
	{
		e.preventDefault();
		var Adhaarnumber = $('#adhaar').val();
		var Application = $('#Application_No').val();
		var dateoftransaction = $('#Date_of_transaction').val();
		var AmountReq = $('#Amount_Req').val();
		var Weight = $('#weight').val();
		var remarks = $('#Details').val();  
		
		if(Adhaarnumber== "" || Application == ""){
			alert("Check the data");
		
			
		}else{
			$.ajax(
			{
				url : 'loanapplication.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,App:Application,dot:dateoftransaction,Amount:AmountReq,weight:Weight,detail:remarks},
			
				success:function(data){
					
									window.open('medicalold.php?id= '+Adhaarnumber,'_self');
									if (confirm('Inserted Successfully'+"\nDo you want to print?")) {
												  
												  window.open('invoice-db.php?id='+Application);
												  
												  
										} else {
										  txt = "You pressed Cancel!";
										}
									$('insert_det')[0].reset();
									$('#newform').modal('hide'); 
									
									
								
						
				}
				
			});
			
		}
	});
}
function app_edit(){
	$(document).on('click','#new_app',function(){
		var adha=$('#Adhaarnumber').val();
		$.ajax(
			{
				url : "app_loandata.php",
				method : 'post',
				data : {adhaar:adha},
				dataType :"JSON",
				beforeSend:function(){  
							
                          $('#new_app').val("Updating");				  
                     },
				success:function(data){
					
					$('#Application_No').val(++data[0]);
					
					$('#newform').modal('show');
					
				}
				
		
		});
	});
}
function edit(){
	$(document).on('click','#editfrm',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_data.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App').val(data.Application_No);
					$('#Up_Adhaar').val(data.Adhaarnumber);
					$('#dot').val(data.dateoftransaction);
					$('#Up_Details').val(data.detail);
					$('#Up_AmountRequested').val(data.Amnt_req);
					$('#Up_AmountSanctioned').val(data.Amnt_Sanc);
					$('#Up_Discharge').val(data.Discharge);
					$('#edit').modal('show');
					
				}
				
		
	});
});
}
function update(){
	$(document).on('click','#update', function(){  
				
				var Adhaarnumber = $('#Up_Adhaar').val();
				var Application = $('#Up_App').val();
				var Details = $('#Up_Details').val();
				var dateoftransaction = $('#dot').val();
				var Amount_Requested = $('#Up_AmountRequested').val(); 
				var Amount_Sanctioned = $('#Up_AmountSanctioned').val();
				var Dischargerep = $('#Up_Discharge').val();				
                $.ajax({ 
					 url:'update.php',  
                     method:"post",  
                     data:{Adhaar:Adhaarnumber,App:Application,Detail:Details,dateoft:dateoftransaction,AmountSanc:Amount_Sanctioned,AmountReq:Amount_Requested,Dr:Dischargerep},  
                     beforeSend:function(){  
                          $('#update').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('medicalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });  
}

