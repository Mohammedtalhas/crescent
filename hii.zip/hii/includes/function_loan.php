<?php 
	require_once('config.php');
	
	function Insertrecordloan(){
		global $mysqli;
		 $Adhaar_No = $_POST['Adhaar'];
		 $First_Name = $_POST['fname'];
         $Last_Name = $_POST['lname'];
         $Date_of_birth = $_POST['dob'];
         $Age = floor((time() - strtotime($Date_of_birth)) / 31556926);
	     $Mobile_No= $_POST['mobile'];
	     $Address = $_POST['addr'];
	     $Town_City = $_POST['tow'];
		 
		
		$SELECT = "SELECT Adhaarnumber From loan Where Adhaarnumber = '$Adhaar_No' Limit 1";
        $INSERT = "INSERT Into loan (Adhaarnumber, firstname, lastname, dateofbirth, mobilenumber, addrss, town) values('$Adhaar_No', '$First_Name', '$Last_Name', '$Date_of_birth', '$Mobile_No', '$Address', '$Town_City')";
		 //Prepare statement
         $stmt = $mysqli->prepare($SELECT);
         $stmt->execute();
         $stmt->bind_result($Adhaar_No);
         $stmt->store_result();
         $rnum = $stmt->num_rows;
         if ($rnum==0) {
          $stmt->close();
          $stmt = $mysqli->prepare($INSERT);
          $stmt->execute();
		  
		  echo true;
    	
         } else {
		 
		  echo false;
		 
		 }
         $stmt->close();
         $mysqli->close();
		
	}
	
	
	function get_loandata(){
		global $mysqli;
		$Adhaar=$_POST['ids'];
		$query="SELECT * FROM loan WHERE Adhaarnumber='$Adhaar'";
		$result=mysqli_query($mysqli,$query);
		$row = mysqli_fetch_array($result);  
		echo json_encode($row);  
	}
	
	
	function get_loanapp_records(){
		
		global $mysqli;
		$app=$_POST['adhaar'];
		$query="SELECT MAX(Application_No) FROM loanapp";
		$result=mysqli_query($mysqli,$query);
		$row = mysqli_fetch_array($result);
		echo json_encode($row);
		
	}
	
	function loanapplication(){
		
		global $mysqli;
		$aadhar_id = $_POST['Adhaar'];
		$Application_No = $_POST['App'];
		$Date_of_transaction = $_POST['dot'];
		$Amount_Req = $_POST['Amount'];
		$Weight = $_POST['weight'];
		$remarks = $_POST['detail'];
		 
		
		
		$INSERT = "INSERT Into loanapp (Application_No,Adhaarnumber, AmountReq, weight, dateofTransaction,remarks) values('$Application_No','$aadhar_id', '$Amount_Req', '$Weight', '$Date_of_transaction','$remarks')";
		 //Prepare statement
		$result=mysqli_query($mysqli,$INSERT);
		if($result){
			echo true;
    	
         } else {
		 
		  echo false;
		 
		 }
	}
	

	

	
	
	function table(){
		global $mysqli;
		$Adhaar=$_POST['ids'];
		$valu="";
		$valu='<div class="row">
					  <div class="col-md-12">
						<div class="x_panel">
						  <div class="x_title">
							<h2>History</h2>
							<ul class="nav navbar-right panel_toolbox">
							  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
							  </li>
							  <li><a class="close-link"><i class="fa fa-close"></i></a>
							  </li>
							</ul>
							<div class="clearfix"></div>
						  </div>
						  <div class="x_content" ><center><h2>No records found!</h2></center></div>
						</div>
					  </div>
					  
					</div>';
		$value="";
		$value='<div class="row">
					  <div class="col-md-12">
						<div class="x_panel">
						  <div class="x_title">
							<h2>History</h2>
							<ul class="nav navbar-right panel_toolbox">
							  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
							  </li>
							  
							  <li><a class="close-link"><i class="fa fa-close"></i></a>
							  </li>
							</ul>
							<div class="clearfix"></div>
						  </div>
						  <div class="x_content" >
						  <table class="table table-striped projects">
							  <thead>
								<tr>
								  <th style="width: 8.9%">Application No.</th>
								  <th style="width: 10%">Adhaar No.</th>
								  <th style="width: 10%">Amount requested</th>
								  <th style="width: 10%">Duration</th>
								  <th style="width: 10%">Date of Sanctioned</th>
								  <th style="width: 10%">Amount Sanctioned</th>
								  <th style="width: 5%">Update</th>
								  <th style="width: 10%">Remarks</th>
								</tr>
							  </thead>
							  <tbody>';
								
								if(true){	
									$sql = "SELECT edunew1.Application_No, edunew1.Adhaarnumber,edunew1.Courseapplied, edunew1.Courseduration,edunew1.Feesstruture,edunew1.Marksobtained,edunew1.dateofsanctioned,edunew1.Amountsanctioned
									FROM edunew1
									INNER JOIN edu ON edunew1.Adhaarnumber=edu.Adhaarnumber Where edunew1.Adhaarnumber  = '$Adhaar' ;

									";
									  $result = $mysqli->query($sql);
									  if ($result->num_rows > 0) {
									   
									   while($row = $result->fetch_assoc()) {
										$value.="<tr><td>" . $row["Application_No"]. "</td><td>" . $row["Adhaarnumber"] . "</td><td>". $row["Courseapplied"] ."</td><td>" . $row["Courseduration"] . "</td><td>" . $row["Feesstruture"] . "</td><td>". $row["Marksobtained"] . "</td><td>" . $row["dateofsanctioned"] . "</td>";
										$value.='<td></td><td></td>';
										$value.="<td>" . $row["Amountsanctioned"]. "</td>";
										$value.='<td><button  class="btn btn-info btn-xs" id="editfrm"  data-id='.$row["Application_No"].'><i class="fa fa-pencil"></i> Edit </button></td><td></td></tr>';
									
									}
									  }else{
										  $value.="";
									  }
									
							echo json_encode(['status'=>'success','html'=>$value]);
								} else 
									{ 
									echo json_encode(['status'=>'failure','html'=>$valu]); 
									}
									$mysqli->close();
							
								
							  
							
	}
	
	
?>