<?php
	require_once('includes/function_edu.php');
	update10();

?>