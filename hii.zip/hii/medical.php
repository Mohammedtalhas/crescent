<?php 

	session_start();
	if(!isset($_GET['id'])){
     
		
	if(!isset($_SESSION['id'],$_SESSION['user_role_id']))
	{
		header('location:index.php?lmsg=true');
		exit;
	}
$_SESSION['previous'] = basename($_SERVER['PHP_SELF']);
	require_once('includes/config.php');
	require_once('sidebar.php'); 
	
	}
?>

<!DOCTYPE html>
 <html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Crescent Welfare Association </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- jQuery custom content scroller -->
    <link href="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
	

	<script>
		 function validate_adhaar() 
          {
            var fnameval=document.getElementById("Adhaarnumber").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0||fnamelen<=11||fnamelen>=13)
               {
                  document.getElementById("Adhaarnumber").style.borderColor = "#FF5733";
				  alert("Enter valid Adhaar number");
				  
		  }else{
			  document.getElementById("Adhaarnumber").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_first() 
          {
            var fnameval=document.getElementById("firstname").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("firstname").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("firstname").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_last() 
          {
            var fnameval=document.getElementById("lastname").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("lastname").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("lastname").style.borderColor = "#85C1E9";
		  }
		  } 
		  function validate_number() 
          {
            var fnameval=document.getElementById("number").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0||fnamelen<=9||fnamelen>=11)
               {
                  document.getElementById("number").style.borderColor = "#e74c3c";
				  alert("Enter valid Mobile number");
		  }else{
			  document.getElementById("number").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_address() 
          {
            var fnameval=document.getElementById("address").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("address").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("address").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_town() 
          {
            var fnameval=document.getElementById("town").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("town").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("town").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_adhaar1() 
          {
            var fnameval=document.getElementById("anumber1").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0||fnamelen<=11||fnamelen>=13)
               {
                  document.getElementById("anumber1").style.borderColor = "#e74c3c";
				  alert("Enter valid Adhaar number");
		  }else{
			  document.getElementById("anumber1").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_first1() 
          {
            var fnameval=document.getElementById("firstname1").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("firstname1").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("firstname1").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_last1() 
          {
            var fnameval=document.getElementById("lastname1").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("lastname1").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("lastname1").style.borderColor = "#85C1E9";
		  }
		  } 
		  function validate_number1() 
          {
            var fnameval=document.getElementById("number1").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0||fnamelen<=9||fnamelen>=11)
               {
                  document.getElementById("number1").style.borderColor = "#e74c3c";
				  alert("Enter valid Mobile number");
		  }else{
			  document.getElementById("number1").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_address1() 
          {
            var fnameval=document.getElementById("address1").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("address1").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("address1").style.borderColor = "#85C1E9";
		  }
		  }
		  function validate_town1() 
          {
            var fnameval=document.getElementById("town1").value;
            var fnamelen=Number(fnameval.length);
               if(fnamelen==0)
               {
                  document.getElementById("town1").style.borderColor = "#e74c3c";
		  }else{
			  document.getElementById("town1").style.borderColor = "#85C1E9";
		  }
		  }
		  </script>
		  
  </head>

  <body class="nav-md footer_fixed">
    <div class="container body">
      <div class="main_container">
        

        <!-- top navigation -->
              <?php require_once('header.php'); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>MEDICAL AID</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                              <button class="btn btn-default" type="button">Go!</button>
                          </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>NEW APPLICANT<small>for medical aid</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Applicant</a>
                        </li>
                        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Alternative</a>
                        </li>
                        
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
					<p id="message"></p>	
                    <form  method="post" id="form1" >
                     

                      <div class="item form-group">
                        <label style="margin-left:45px;color:black" ><strong>Adhaar No: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="Adhaarnumber" name="Adhaarnumber" title="Enter 12 digit number" maxlength="12" style="padding-bottom:6px;width:200px;"  onblur="validate_adhaar()"  required="required" >
                      </div>
                      <div class="item form-group">
                        <label style="margin-left:44px;color:black"  ><strong>First Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="firstname" name="firstname" required="required" onblur="validate_first()" placeholder="" style="padding-bottom:6px;width:200px;">
                     
                        <label style="padding-left:60px;color:black" ><strong>Last Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="lastname" name="lastname" onblur="validate_last()"  placeholder="" required="required" style="padding-bottom:6px;width:200px;">
						<label style="padding-left:60px;color:black;" for="dateofbirth"><strong>Date Of Birth: <span class="required">*</span>&nbsp;</strong>
						<input type="date"  required="required" id="dateofbirth" name="dateofbirth" style="padding-bottom:6px;width:128px;">
					  </div>
                      <div class="item form-group">
                        <label style="margin-left:48px;color:black;" ><strong>Mobile No: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="number" name="mobilenumber" required="required" onblur="validate_number()" maxlength="12"  style="padding-bottom:6px;width:200px;"> 
                      
                        <label style="padding-left:75px;color:black;" ><strong>Address: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="address" name="address" required="required" onblur="validate_address()" style="padding-bottom:6px;width:200px;">
                      
                        <label style="padding-left:60px;color:black;"><strong>Town/City: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input id="town" type="text" name="town" onblur="validate_town()" style="padding-bottom:6px;width:200px;">
                        
                      </div>
                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <button id="refr" class="btn btn-primary">Cancel</button>
                          <button id="add" name="add" type="submit" class="btn btn-success">submit</button>
                        </div>
                      </div>
                    </form>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                          <form class="form-horizontal form-label-left" id="form2" method="post">
                     

                      <div class="item form-group">
                        <label style="margin-left:45px;color:black" ><strong>Adhaar No: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="anumber1" name="Adhaarnumber1" maxlength="12" style="padding-bottom:6px;width:200px;"  onblur="validate_adhaar1()"  required="required" >
                      </div>
                      <div class="item form-group">
                        <label style="margin-left:45px;color:black"  ><strong>First Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="firstname1" name="firstname1" required="required" onblur="validate_first1()" placeholder="" style="padding-bottom:6px;width:200px;">
                     
                        <label style="padding-left:75px;color:black" ><strong>Last Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="lastname1" name="lastname1" onblur="validate_last1()"  placeholder="" required="required" style="padding-bottom:6px;width:200px;">
						<label style="padding-left:70px;color:black;" for="dateofbirth1"><strong>Date Of Birth: <span class="required">*</span>&nbsp;</strong>
						<input type="date"  required="required" id="dateofbirth1" name="dateofbirth1" style="padding-bottom:6px;width:128px;">
					  </div>
                      <div class="item form-group">
                        <label style="margin-left:45px;color:black;" ><strong>Mobile No: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="number1" name="mobilenumber1" required="required" onblur="validate_number1()" maxlength="12"  style="padding-bottom:6px;width:200px;"> 
                      
                        <label style="padding-left:75px;color:black;" ><strong>Address: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="address1" name="address1" required="required" onblur="validate_address1()" style="padding-bottom:6px;width:200px;">
                      
                        <label style="padding-left:70px;color:black;"><strong>Town/City: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input id="town1" type="text" name="town1" onblur="validate_town1()" style="padding-bottom:6px;width:200px;">
                        
                      </div>
                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <button  class="btn btn-primary">Cancel</button>
                          <button id="Submit1" name="Submit1" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
		        <?php require_once('footer.php'); ?>	


              </div>
    </div>
	
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- jQuery custom content scroller -->
    <script src="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
 
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
<script>
$(document).ready(function()
{
	Insert_record();
	Insert_record1();
	
})

function Insert_record()
{	
	$('#form1').submit(function()
	{
		
		var Adhaarnumber = $('#Adhaarnumber').val();
		var firstname = $('#firstname').val();
		var lastname = $('#lastname').val();
		var dateofbirth = $('#dateofbirth').val();
		var mobilenumber = $('#number').val();
		var address = $('#address').val();
		var town = $('#town').val();
		if(Adhaarnumber== "" || firstname == "" || lastname == "" || mobilenumber==""||address==""||town==""||dateofbirth==""){
			alert("Fill All the fields");
		}else{
			$.ajax(
			{
				url : 'insert.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,fname:firstname,lname:lastname,dob:dateofbirth,mobile:mobilenumber,addr:address,tow:town},
				success:function(data){
			
					alert(data);
					window.open('medicalold.php?id= '+Adhaarnumber,'_self');
					
				
				}
				
			})
		}
	})
	$(document).on('click','#refr',function()
	{
		$('#form1').trigger('reset');
	})
}
function Insert_record1()
{	
	$('#form2').submit(function()
	{
		
		var Adhaarnumber = $('#anumber1').val();
		var firstname = $('#firstname1').val();
		var lastname = $('#lastname1').val();
		var dateofbirth = $('#dateofbirth1').val();
		var mobilenumber = $('#number1').val();
		var address = $('#address1').val();
		var town = $('#town1').val();
		if(Adhaarnumber== "" || firstname == "" || lastname == "" || mobilenumber==""||address==""||town==""||dateofbirth==""){
			alert("Fill All the fields");
		}else{
			$.ajax(
			{
				url : 'insert.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,fname:firstname,lname:lastname,dob:dateofbirth,mobile:mobilenumber,addr:address,tow:town},
				success:function(data){
					alert(data);
					window.open('medicalold.php?id= '+Adhaarnumber,'_self');
				
				}
				
			})
		}
	})
	$(document).on('click','#refr',function()
	{
		$('#form2').trigger('reset');
	})
}
</script>