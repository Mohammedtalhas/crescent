<?php
	require_once('includes/function_edu.php');
	get_records();

?>