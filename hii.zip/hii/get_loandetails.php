<?php
	
	require_once('includes/function_loan.php');
	get_loandata();
	
?>
