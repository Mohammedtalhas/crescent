<?php
	require_once('includes/function_edu.php');
	require_once('includes/config.php');
	table();

?>

