<?php
	require_once('includes/functions.php');
	require_once('includes/config.php');
	update();
?>