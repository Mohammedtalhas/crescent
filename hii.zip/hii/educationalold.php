<?php 

	session_start();
	if(!isset($_GET['id'])){
     
		
	if(!isset($_SESSION['id'],$_SESSION['user_role_id']))
	{
		header('location:index.php?lmsg=true');
		exit;
	}
$_SESSION['previous'] = basename($_SERVER['PHP_SELF']);
	require_once('includes/config.php');
	require_once('sidebar.php'); 
	
	}
?>





<!DOCTYPE html>
 <html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Crescent Welfare Association</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- jQuery custom content scroller -->
    <link href="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>


    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
	<script>
  
	


  </script>
  </head>
  

  <body class="nav-md footer_fixed">
    <div class="container body">
      <div class="main_container">
        
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
     <?php require_once('header.php'); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>MEDICAL AID</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
				<form id="demo" >
                  <div class="input-group">
					<input  class="form-control" list="search" id="input">
					<datalist id="search">
						<?php
							while($row= mysqli_fetch_array($result)){
								echo '<option type="text" value="'.$row['Adhaarnumber'].'" class="form-control" >'.$row['lastname'].'</option>';
								}
							 
						?>
					 
					 </datalist>
                    <span class="input-group-btn">
                              <button id="go" name="go"class="btn btn-default" type="button">Go!</button>
                          </span>
                  </div>
				  </form>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>NEW APPLICANT<small>for Educational aid</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Applicant</a>
                        </li>
                        
                        
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
						
                    
                     

                      <div class="item form-group">
                        <label style="margin-left:30px;color:black" ><strong>Adhaar No / ID : <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="Adhaarnumber" name="Adhaarnumber"  maxlength="12" style="padding-bottom:6px;width:200px;" readonly >
                        
                      </div>
                      <div class="item form-group">
                        <label style="margin-left:54px;color:black"  ><strong>First Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="firstname" name="firstname" readonly placeholder="" style="padding-bottom:6px;width:200px;">
                     
                        <label style="padding-left:60px;color:black" ><strong>Last Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="lastname" name="lastname"  readonly placeholder="" style="padding-bottom:6px;width:200px;">
						<label style="padding-left:70px;color:black" for="dateofbirth"><strong>Date Of Birth: <span class="required">*</span>&nbsp;</strong>
						<input type="date" id="dateofbirth" name="dateofbirth" readonly style="padding-bottom:6px;width:128px;">
					  </div>
                      <div class="item form-group">
                        <label style="margin-left:58px;color:black" ><strong>Father Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="Fathername" name="Fathername"  readonly  style="padding-bottom:6px;width:200px;">
						
						<label style="margin-left:58px;color:black" ><strong>Mobile No: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="number" name="mobilenumber"  readonly  style="padding-bottom:6px;width:200px;"> 
                      </div>
                      <div class="item form-group">
                        <label style="padding-left:75px;color:black" ><strong>Address: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="address" name="address" readonly style="padding-bottom:6px;width:200px;">
                      
                        <label style="padding-left:70px;color:black"><strong>Town/City: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input id="town" type="text" name="town"  readonly style="padding-bottom:6px;width:200px;">
                        
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <button  class="btn btn-primary">Cancel</button>
                          <button id="new_app" class="btn btn-success">New Application</button>
                        </div>
                      </div>
                    
                        </div>
             
                        
                      </div>

                    </div>
                  </div>
                </div>
				
				
				  <div id="table">
					

							
						  
				  </div>
				  </tbody>
							</table>
							</div>
						</div>
					  </div>
					  
					</div>
				  <br>
				  <br>
				  <!-- Modal -->
				  <div class="modal fade bs-example-modal-lg" id="newform" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">New Application</h4>
						  
                        </div>
                        <div class="modal-body">
						<p id="message"></p>
						<form id="insert_det">
							 <div class="form-group">
								<input type="hidden" name = "adhaar" id="adhaar">
								<label style="padding-left:100px;"><strong>Application No.:&nbsp;</strong></label>
								<input name="Application_No" id="Application_No" type="text" style="padding-bottom:6px;width:200px;" value="<?php echo $Application+1; ?>" readonly>
								
								<label style="padding-left:70px;"><strong>Date of transaction:&nbsp;</strong></label>
								<input type="text" value="<?php echo date("Y-m-d"); ?>"  name="Date_of_transaction" id="Date_of_transaction" style="padding-bottom:6px;width:128px;"> 
							 
							 </div>
							 <div class="form-group">
								<label style="margin-left:76px;padding-left:3px"><strong>Course Duration:&nbsp;</strong></label>
								<select id="course_dur" name="course_dur">
								<option ></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3 </option>
								<option value="4">4 </option></select>
								
								
								<label style="margin-left:76px;padding-left:3px"><strong>Course Applied:&nbsp;</strong></label>
								<input id="course_appl" name="course_appl" type="text" style="padding-bottom:6px;width:200px;">
								</div>
							
							</div>
							<div class="form-group">
								<div class="col">
								
								<div class="col"><label style="margin-left:76px;padding-left:3px"><strong>Institution Applied:&nbsp;</strong></label>
								<input id="Inst_appl" name="Inst_appl" type="text" style="padding-bottom:6px;width:200px;">
								</div>
							</div>
							
							
							<div class="form-group">
								<div class="col">
								<label style="margin-left:80px"><strong>Fees Structure:&nbsp;</strong></label>
								<input id="Fees" name="Fees" type="text" style="padding-bottom:6px;width:200px;">
								<label style="margin-left:80px"><strong>Last Studied:&nbsp;</strong></label>
								<input id="Last_studied" name="Last_studied" type="text" style="padding-bottom:6px;width:200px;">
								<label style="margin-left:80px"><strong>Marks Obtained:&nbsp;</strong></label>
								<input id="Marks_obt" name="Marks_obt" type="text" style="padding-bottom:6px;width:200px;">
								
							</div>
							
							<div class="form-group">
							<br>
							<div class="col"><label style="margin-left:80px"><strong>Remarks: &nbsp;</strong></label><input name="Details" id="Details" type="textarea" style="padding-bottom:6px;width:580px;"></div>
							</div>
							
														
								
			
							
							
					
							</div>
							  </div>
						  
							<div class="modal-footer">
							  
						  <div >
							<div class="col-md-6 col-sm-6 col-xs-12">
							  <div>
							  <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
							  <button type="submit" class="btn btn-success" name="enter" id="enter">Submit</button>
							  </div>
							  
							</div>
						  </div>
					  </form>
                        </div>

                      </div>
                    </div>
                  </div>
				  <center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App1" name="Up_App1" readonly>
							<input type="hidden" name="action" id="action" value="insert" />
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee1" name="Up_fee1" readonly>
						
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks1" name="Up_marks1" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot1" name="dot1" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount1" name="Up_Amount1" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet1" name="Up_marksheet1">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update1"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit1">
					<div class="modal-dailog modal-lg">
						<div class="modal-content"> 
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form2" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App2" name="Up_App2" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee2" name="Up_fee2" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks2" name="Up_marks2" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot2" name="dot2" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount2" name="Up_Amount2" >
							
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet2" name="Up_marksheet2">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update2"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit12">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form3" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App21" name="Up_App21" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee21" name="Up_fee21" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks21" name="Up_marks21" >
							
							<label><strong>No of Arrear.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Arrear21" name="Up_Arrear21" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot21" name="dot21" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount21" name="Up_Amount21" >
							
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet21" name= "Up_marksheet21">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update22"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit21">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form4" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App31" name="Up_App31" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee31" name="Up_fee31" readonly>
							
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks31" name="Up_marks31" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot31" name="dot31" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount31" name="Up_Amount31" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet31" name="Up_marksheet31">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update31"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit22">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form5" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App32" name="Up_App32" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee32" name="Up_fee32" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks32" name="Up_marks32" >
							
							<label><strong>No of Arrear.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Arrear32" name="Up_Arrear32" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot32" name="dot32" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount32" name="Up_Amount32"  >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet32" name="Up_marksheet32" >
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update32"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit23">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form6" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App33" name="Up_App33" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee33" name="Up_fee33" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks33" name="Up_marks33" >
							
							<label><strong>No of Arrear.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Arrear33" name="Up_Arrear33" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot33" name="dot33" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount33" name="Up_Amount33" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet33" name="Up_marksheet33">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update33"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit41">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form7" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App41" name="Up_App41" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee41" name="Up_fee41" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks41" name="Up_marks41" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot41" name="dot41" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount41" name="Up_Amount41" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet41" name="Up_marksheet41">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update41"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit42">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form8" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App42" name="Up_App42" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee42" name="Up_fee42" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks42" name="Up_marks42" >
							
							<label><strong>No of Arrear.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Arrear42" name="Up_Arrear42" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot42" name="dot42" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount42" name="Up_Amount42" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet42" name="Up_marksheet42">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update42"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit43">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form9" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App43" name="Up_App43" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee43" name="Up_fee43"  readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks43" name="Up_marks43" >
							
							<label><strong>No of Arrear.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Arrear43" name="Up_Arrear43" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot43" name="dot43" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount43" name="Up_Amount43" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet43" name="Up_marksheet43">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update43"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				<center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit44">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form10" method="post" enctype="multipart/form-data">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App44" name="Up_App44" readonly>
							
							<label><strong>Fee Structure:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_fee44" name="Up_fee44" readonly>
							
							<label><strong>Marks Obtained:&nbsp;</strong></label>
							<input type="number" class="form-control" placeholder="" id="Up_marks44" name="Up_marks44" >
							
							<label><strong>No of Arrear.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Arrear44" name="Up_Arrear44" >
							
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="date" class="form-control" placeholder="" id="dot44" name="dot44" >
							
							<label><strong>Amount Sanctioned:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Amount44" name="Up_Amount44" >
							<br>
								<br>
							<label><strong>Mark sheet.:&nbsp;</strong></label>
							<input type="file" class="form-control" placeholder="" id="Up_marksheet44" name="Up_marksheet44">
							
							
							</div>
							<div class="modal-footer">
							<input type="submit" class="btn btn-success" value="Update" id="update44"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
		
				  <!--Modalend-->
              </div>
            </div>  
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
       <?php	require_once('footer.php');?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
	<script src="functionedu.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- jQuery custom content scroller -->
    <script src="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- validator -->
    <script src="../vendors/validator/validator.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
