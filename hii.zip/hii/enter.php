<?php
	require_once('includes/functions.php');
	 medicalapplication();
?>