<?php
require_once ('includes/config.php');
global $mysqli;
$query = '';

if($_POST['name']=='username'){
    $id = $_POST['pk'];
    $username = $_POST['value'];
    $result = mysqli_query($mysqli, "SELECT Application_No FROM loanapp WHERE Application_No=$id") or die(mysqli_error($mysqli)); 
    
	if (mysqli_num_rows($result) > 0) {
       $query = "UPDATE loanapp SET one='".$username."' WHERE Application_No=$id"; 
	   if ( !empty($query) && mysqli_query($mysqli, $query)){
		    echo '<Script>alert("Inserted");</script>';
	   }
    }
	
	
	
}



if($_POST['name']=='dob'){
    $id=$_POST['pk'];
    $dob=$_POST['value'];
	
    $result=mysqli_query($mysqli, "SELECT id FROM sample WHERE id=$id") or die(mysqli_error($mysqli));
	
    if (mysqli_num_rows($result) > 0) {
       
       $query = "UPDATE loanapp SET onedate='".$dob."' WHERE Application_No=$id"; 
	   if ( !empty($query) && mysqli_query($mysqli, $query)){
		   echo '<Script>alert("Inserted");</script>';
	   }
    }
    
}





?>