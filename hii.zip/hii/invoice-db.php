<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
header('Content-Type: text/html; charset=utf-8');
//call the FPDF library
require('fpdf17/fpdf.php');
$val = $_GET['id'];
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'test');
$query = mysqli_query($con, "select * from mednew where Application_No =  '$val'");
$id = mysqli_fetch_array($query);
$adhar=	$id['Adhaarnumber'];
$query1 = mysqli_query($con, "select * from med where Adhaarnumber =  '$adhar'");

$row = mysqli_fetch_array($query1);
//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm

//create pdf object
$pdf = new FPDF('P','mm','A4');
//add new page

$pdf->AddPage();


//output the result
$pdf->SetFont('Arial','b',18);
$pdf->Cell( 190, 265, '', 1);


$pdf->SetFont('Arial','b',24);

//Cell(width , height , text , border , end line , [align] )


$pdf->SetXY( 30, 23 ) ; $pdf->Cell($pdf->GetStringWidth("CRESCENT WELFARE ASSOCIATION"), 0, "CRESCENT WELFARE ASSOCIATION", 0, "");
$pdf->SetFont('Arial','',12);
$pdf->SetXY( 65, 33 ) ; $pdf->Cell($pdf->GetStringWidth("No.255,Anna Saalai,Melvisharam,632509"), 0, "No.255,Anna Saalai,Melvisharam,632509", 0, "");
$pdf->Cell(189 ,10,'',0,1);

//sample
// Set font
$pdf->SetFont('Arial','B',16);
// Move to 8 cm to the right
$pdf->Cell(80);
// Centered text in a framed 20*10 mm cell and line break
$pdf->Cell(20,5,'MEDICAL AID FORM',0,0,'C');

//sample ends
$pdf->Cell(-10 ,10,'',0,1);


$pdf->Cell(20,3,'____________________________________________________________',0,0);
$pdf->Cell(189 ,10,'',0,1);



//head
//set font to arial, regular, 12pt
$pdf->SetFont('Arial','',12);
$pdf->Cell(30 ,5,'Application No.:',0,0);
$pdf->Cell(4);
$pdf->SetFont('Arial','u',12);
$pdf->Cell(30 ,5,$id['Application_No'],0,0);//end of line
$pdf->Cell(70);
$pdf->SetFont('Arial','',12);
$pdf->Cell(12,5,'Date:',0,0);
$pdf->Cell(20,5,$id['dateoftransaction'],0,1);//end of line
//head end

$pdf->Cell(100 ,5,'',0,1);
$pdf->SetFont('Arial','',12);
$pdf->Cell(25,5,'Adhaar No.:',0,0);
$pdf->Cell(20,5,$id['Adhaarnumber'],0,1);
$pdf->Cell(100 ,5,'',0,1);
//head
//set font to arial, regular, 12pt
//Cell(width , height , text , border , end line , [align] )
$pdf->SetFont('Arial','',12);
$pdf->Cell(20 ,4,'Name   :',0,0);
$pdf->SetFont('Arial','u',12);
$pdf->Cell(25 ,4,$row['firstname'],0,0);//end of line
$pdf->Cell(2);

$pdf->SetFont('Arial','u',12);
$pdf->Cell(20,4,$row['lastname'],0,1);//end of line
//head end
$pdf->Cell(189 ,10,'',0,1);

//head
//set font to arial, regular, 12pt
$pdf->SetFont('Arial','',12);
$pdf->Cell(20 ,4,'mobile:',0,0);
$pdf->Cell(10 ,4,$row['mobilenumber'],0,0);
$pdf->Cell(20);
$pdf->SetFont('Arial','',12);
$pdf->Cell(20 ,4,'Age: 25',0,0);
$pdf->Cell(30 ,4,$id['age'],0,0);//end of line
$pdf->Cell(3);

//head end


$pdf->Cell(189 ,10,'',0,1);
//head
//set font to arial, regular, 12pt

//head end
$pdf->Cell(20 ,4,'Details of Medical Report:',0,0);
$pdf->Cell(189 ,5,'',0,1);
$pdf->MultiCell( 185, 7, '', 1);


$pdf->Cell(189 ,10,'',0,1);
$pdf->SetFont('Arial','b',12);
$pdf->multiCell(40 ,4,'DECLARATION:',0,1);

$pdf->Image('tami.png', 15, 140, 180, 25);
$pdf->Cell(189 ,20,'',0,2);
$pdf->Image('urd.png', 15, 165, 180, 25);
$pdf->Cell(189 ,10,'',0,1);
$pdf->Cell(189 ,10,'',0,1);
$pdf->Cell(189 ,10,'',0,1);

$pdf->Cell(-10 ,10,'',0,1);



$pdf->Cell(20,10,'________________________________________________________________________________',0,0);
$pdf->Cell(189 ,10,'',0,1);


$pdf->SetFont('Arial','B',12);
$pdf->Cell(55 ,4,'Sanctioned a Sum of Rs:',0,0);
$pdf->SetFont('Arial','u',12);
$pdf->Cell(70 ,4,$id['Amnt_sanc'],0,0);//end of line


//$pdf->SetFont('Arial','B',12);
//$pdf->Cell(15 ,4,'rupees:',0,0);
//$pdf->Cell(3);
//$pdf->SetFont('Arial','u',12);
//$pdf->multiCell(60 ,4,'',1,0);//end of line



$pdf->SetXY( 30, 250 ) ; $pdf->Cell($pdf->GetStringWidth("Secratary"), 0, "Secratary", 0, "");
$pdf->SetXY( 145, 250 ) ; $pdf->Cell($pdf->GetStringWidth("receiver's signature"), 0, "receiver's signature", 0, "");
//make a dummy empty cell as a vertical spacer


ob_end_clean();
$pdf->Output();

?>