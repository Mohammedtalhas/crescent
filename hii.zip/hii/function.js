$(document).ready(function()
{
	Insert_record();
	edit();
	update();
	get();
	app_edit();
	getUrlVars();
	$("#input").click(function(){
        $(this).next().show();
        $(this).next().hide();
    });

	$('#mop').on('change', function() {
      if ( this.value == 'cheque')
      {
        $("#myDIV").show();
      }
      else
      {
        $("#myDIV").hide();
      }
    });

	
	
})


function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=%20');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
     var ids = vars['id'];
	
	
	if(ids!=''){
		
		
			
			$.ajax(
				{
					url : 'get_details.php',
					method : 'post',
					data :{ids:ids},
					dataType :"JSON",
					success:function(data){
					
						$('#Adhaarnumber').val(data.Adhaarnumber);
						$('#firstname').val(data.firstname);
						$('#lastname').val(data.lastname);
						$('#dateofbirth').val(data.dateofbirth);
						$('#number').val(data.mobilenumber);
						$('#address').val(data.addrss);
						$('#town').val(data.town);
						$('#adhaar').val(data.Adhaarnumber);
						$.ajax(
						{
							url : 'table.php',
							method : 'post',
							data :{ids:ids},
							success:function(data){
									$('#table').html(data);
								
							}
						});
						
					}
					
			
		});
			
			
	
}
}

function get(){
	$(document).on('click','#go',function(){
		var ids =$('#input').val();
		
		if(ids != ''){
			$.ajax(
				{
					url : 'get_details.php',
					method : 'post',
					data :{ids:ids},
					dataType :"JSON",
					success:function(data){
					
						$('#Adhaarnumber').val(data.Adhaarnumber);
						$('#firstname').val(data.firstname);
						$('#lastname').val(data.lastname);
						$('#dateofbirth').val(data.dateofbirth);
						$('#number').val(data.mobilenumber);
						$('#address').val(data.addrss);
						$('#town').val(data.town);
						$('#adhaar').val(data.Adhaarnumber);
						$.ajax(
							{
								url : 'table.php',
								method : 'post',
								data :{ids:ids},
								success:function(data){
									
									
										$('#table').html(data);
										
								}
							});
						
					}
					
			
		});
		
	}
});
}
function Insert_record()
{	
	$('#insert_det').submit(function(e)
	{
		e.preventDefault();
		var Adhaarnumber = $('#adhaar').val();
		var Application = $('#Application_No').val();
		var dateoftransaction = $('#Date_of_transaction').val();
		var Amount_Requested = $('#Amount_Requested').val();
		var freq = $('#freq').val();
		var purpose = $('#purpose').val();
		var Details = $('#Details').val();		
		var mop = $('#mop').val();
		var chequeno = $('#chequeno').val();
		var disrep = $('#disrep').val();
		var Amount_Sanctioned = $('#Amount_Sanctioned').val();   
		var file=$('#image').val();
		if(Adhaarnumber== "" || Application == "" || Amount_Requested == "" || freq == "" || purpose == "" || mop == "" || disrep == "" || dateoftransaction==""|| Amount_Sanctioned==""||file=""){
			alert("Check the data");
			window.open('medicalold.php?id= '+Adhaarnumber,'_self');
			
		}else{
			
			$.ajax(
			{
				url : 'enter.php',
				method : 'post',
				data :new FormData(this),
				contentType:false,
				processData:false,
				success:function(data){
					
									window.open('medicalold.php?id= '+Adhaarnumber,'_self');
									if (confirm(data+"\nDo you want to print?")) {
												  
												  window.open('invoice-db.php?id='+Application);
												  
												  
										} else {
										  txt = "You pressed Cancel!";
										}
									$('insert_det')[0].reset();
									$('#newform').modal('hide'); 
									
									
									
								
						
				}
				
			});
			
		}
	});
}
function app_edit(){
	$(document).on('click','#new_app',function(){
		var adha=$('#Adhaarnumber').val();
		$.ajax(
			{
				url : "app_data.php",
				method : 'post',
				data : {adhaar:adha},
				dataType :"JSON",
				beforeSend:function(){  
							
                          $('#new_app').val("Updating");				  
                     },
				success:function(data){
					$('#Application_No').val(++data[0]);
					
					$('#newform').modal('show');
					
				}
				
		
		});
	});
}
function edit(){
			$(document).on('click','.editfrm',function(){
				var Appli=$(this).attr('data-id');
				$.ajax(
				{
				url : 'get_data.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App').val(data.Application_No);
					$('#Up_Adhaar').val(data.Adhaarnumber);
					$('#Up_Details').val(data.Detail);
					$('#dot').val(data.dateoftransaction);
					$('#Up_AmountRequested').val(data.Amnt_req);
					$('#Up_AmountSanctioned').val(data.Amnt_Sanc);
					$('#Up_Discharge').val(data.Discharge);
					$('#edit').modal('show');
				}
				});
});

		
}
function update(){
	$('#insert_form').submit(function(){  
				
				var Adhaarnumber = $('#Up_Adhaar').val();
				var Application = $('#Up_App').val();
				var Details = $('#Up_Details').val();
				var dateoftransaction = $('#dot').val();
				var Amount_Requested = $('#Up_AmountRequested').val(); 
				var Amount_Sanctioned = $('#Up_AmountSanctioned').val();
				var Dischargerep = $('#Up_Discharge').val();
				var succ = $('#success').val();
                $.ajax({ 
					 url:'update.php',  
                     method:"post",  
                     data:{Adhaar:Adhaarnumber,App:Application,Detail:Details,dateoft:dateoftransaction,AmountSanc:Amount_Sanctioned,AmountReq:Amount_Requested,Dr:Dischargerep,succ:succ},  
                     beforeSend:function(){  
                          $('#update').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('medicalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });  
}
