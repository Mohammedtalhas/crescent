<?php

	require_once('includes/functions.php');
	get_app_records();
	

?>
