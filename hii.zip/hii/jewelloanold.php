<?php
require_once('includes/config.php');
//getting id from url


//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM loan ;");

	

?>





<!DOCTYPE html>
 <html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Crescent Welfare Association</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- jQuery custom content scroller -->
    <link href="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
	<link href="../vendor/bootstrap-datetimepicker/build/css/datepicker.css" rel="stylesheet" media="screen">
	<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
	<script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
	<script src="../vendor/bootstrap-datetimepicker/build/js/bootstrap-datepicker.js"></script>

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
	<script>
		function highlightEdit(editableObj) {
	$(editableObj).css("background","#FFF");
} 

function saveInlineEdit(editableObj,column,id) {
	// no change change made then return false
	if($(editableObj).attr('data-old_value') === editableObj.innerHTML)
	return false;
	// send ajax to update value
	$(editableObj).css("background","#FFF url(loader.gif) no-repeat right");
	$.ajax({
		url: "saveInlineEdit.php",
		cache: false,
		data:'column='+column+'&value='+editableObj.innerHTML+'&id='+id,
		success: function(response)  {
			console.log(response);
			// set updated value as old value
			$(editableObj).attr('data-old_value',editableObj.innerHTML);
			$(editableObj).css("background","#FDFDFD");			
		}          
   });
}
	


  </script>
  </head>
  

  <body class="nav-md footer_fixed">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><i class="fa fa-moon-o"></i> <span>CRESCENT</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                    <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Home </a>
                    
                  </li>
                  <li><a><i class="fa fa-edit"></i> Dashboard <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.html">General Form</a></li>
                    </ul>
                  </li>
                  
				  <li><a><i class="fa fa-heartbeat"></i>Medical Aid <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.html">General Form</a></li>
                    </ul>
                  </li>
				  
				  <li><a><i class="fa fa-graduation-cap"></i>Educational Aid <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.html">General Form</a></li>
                    </ul>
                  </li>
				  
				  <li><a><i class="fa fa-diamond"></i> Jewel Loan <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.html">General Form</a></li>
                    </ul>
                  </li>
				  
                </ul>
                  </li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="images/img.jpg" alt="">Admin
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> Profile</a></li>
                    <li>
                      <a href="javascript:;">
                        <span class="badge bg-red pull-right">50%</span>
                        <span>Settings</span>
                      </a>
                    </li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>

                <li role="presentation" class="dropdown">
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-envelope-o"></i>
                    <span class="badge bg-green">6</span>
                  </a>
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="text-center">
                        <a>
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>

        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>MEDICAL AID</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
				<form id="demo" >
                  <div class="input-group">
					<input  class="form-control" list="search" name="input" id="input">
					<datalist id="search">
						<?php
							while($row= mysqli_fetch_array($result)){
								echo '<option type="text" value="'.$row['Adhaarnumber'].'" class="form-control" >'.$row['lastname'].'</option>';
								}
							 
						?>
					 
					 </datalist>
                    <span class="input-group-btn">
                              <button id="go" name="go"class="btn btn-default" type="button">Go!</button>

                          </span>
                  </div>
				  </form>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>NEW APPLICANT<small>for Educational aid</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Applicant</a>
                        </li>
                        
                        
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
						
                    
                     

                      <div class="item form-group">
                        <label style="margin-left:30px;color:black" ><strong>Adhaar No / ID : <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="Adhaarnumber" name="Adhaarnumber"  maxlength="12" style="padding-bottom:6px;width:200px;" readonly >
                        
                      </div>
                      <div class="item form-group">
                        <label style="margin-left:54px;color:black"  ><strong>First Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="firstname" name="firstname" readonly placeholder="" style="padding-bottom:6px;width:200px;">
                     
                        <label style="padding-left:60px;color:black" ><strong>Last Name: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="lastname" name="lastname"  readonly placeholder="" style="padding-bottom:6px;width:200px;">
						<label style="padding-left:70px;color:black" for="dateofbirth"><strong>Date Of Birth: <span class="required">*</span>&nbsp;</strong>
						<input type="date" id="dateofbirth" name="dateofbirth" readonly style="padding-bottom:6px;width:128px;">
					  </div>
                      <div class="item form-group">
            			<label style="margin-left:58px;color:black" ><strong>Mobile No: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="number" id="number" name="mobilenumber"  readonly  style="padding-bottom:6px;width:200px;"> 
                      </div>
                      <div class="item form-group">
                        <label style="padding-left:75px;color:black" ><strong>Address: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input type="text" id="address" name="address" readonly style="padding-bottom:6px;width:200px;">
                      
                        <label style="padding-left:70px;color:black"><strong>Town/City: <span class="required">*</span>&nbsp;</strong>
                        </label>
                        <input id="town" type="text" name="town"  readonly style="padding-bottom:6px;width:200px;">
                        
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <button  class="btn btn-primary">Cancel</button>
                          <button id="new_app" class="btn btn-success">New Application</button>
                        </div>
                      </div>
                    
                        </div>
             
                        
                      </div>

                    </div>
                  </div>
                </div>
				
				
				  <div id="table">
					<div class="row">
					  <div class="col-md-12">
						<div class="x_panel">
						  <div class="x_title">
							<h2>History</h2>
							<ul class="nav navbar-right panel_toolbox">
							  
							  
							  <li><a class="close-link"><i class="fa fa-close"></i></a>
							  </li>
							</ul>
							<div class="clearfix"></div>
						  </div>
						 
						  
								<?php 
									if($_GET['id']){
									$hlo=$_GET['id'];
									global $mysqli;
									$sql = "SELECT loanapp.Application_No, loanapp.Adhaarnumber,loanapp.AmountReq, loanapp.weight,loanapp.dateofTransaction,loanapp.remarks,loanapp.one,loanapp.onedate,loanapp.two,loanapp.twodate,
									loanapp.three,loanapp.threedate,loanapp.four,loanapp.fourdate,loanapp.five,loanapp.fivedate,loanapp.six,loanapp.sixdate,loanapp.seven,loanapp.sevendate,loanapp.eight,loanapp.eightdate,loanapp.nine,loanapp.ninedate,loanapp.tendate,loanapp.ten
									FROM loanapp
									INNER JOIN loan ON loanapp.Adhaarnumber=loan.Adhaarnumber Where loanapp.Adhaarnumber =$hlo ";
									  $result = $mysqli->query($sql);
									  if ($result->num_rows > 0) {
										   while($row = $result->fetch_assoc()) {
											   ?>
											  
										  <div class="card">
      <div class="card-header">
        <a class="collapsed card-link" data-toggle="collapse" href="#<?php  echo $row["Application_No"]; ?>">
        APPLICATION:   <?php  echo $row["Application_No"]; ?>      LOAN AMOUNT:   <?php echo $row["AmountReq"]; ?>  WEIGHT:   <?php echo $row["weight"]; ?>  DATE OF ISSUE:   <?php echo $row["dateofTransaction"]; ?>
		
      </a>
      </div>
	  <br>
      <div id="<?php  echo $row["Application_No"]; ?>" class="collapse" data-parent="#accordion">
        <div class="card-body">
		<table class="table table-striped projects">
		<thead>
		  <tr>			
			<th>paid on</th>
			<th>Amount paid</th>			
		  </tr>
		</thead>
		<tbody>	
		
							 <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["one"]; ?>" onBlur="saveInlineEdit(this,'one','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["one"]; ?></td>
				  <td><input contenteditable="true" data-old_value="<?php echo $row["onedate"]; ?>"  onBlur="saveInlineEdit(this,'onedate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit('<?php echo $row["onedate"]; ?>');" type="date" value="<?php echo $row["onedate"]; ?>"/></td>
				  
					
				  
			  </tr> <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["two"]; ?>" onBlur="saveInlineEdit(this,'two','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["two"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["twodate"]; ?>"  onBlur="saveInlineEdit(this,'twodate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["twodate"]; ?></td>
				  
				  
			  </tr>
           <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["three"]; ?>" onBlur="saveInlineEdit(this,'three','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["three"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["threedate"]; ?>"  onBlur="saveInlineEdit(this,'threedate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["threedate"]; ?></td>
				  
				  
			  </tr>
          
		   <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["four"]; ?>" onBlur="saveInlineEdit(this,'four','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["four"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["fourdate"]; ?>"  onBlur="saveInlineEdit(this,'fourdate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["fourdate"]; ?></td>
				  
				  
			  </tr>
          
		   <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["five"]; ?>" onBlur="saveInlineEdit(this,'five','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["five"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["fivedate"]; ?>"  onBlur="saveInlineEdit(this,'fivedate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["fivedate"]; ?></td>
				  
				  
			  </tr>
			  
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["six"]; ?>" onBlur="saveInlineEdit(this,'six','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["six"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["sixdate"]; ?>"  onBlur="saveInlineEdit(this,'sixdate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["sixdate"]; ?></td>
				  
				  
			  </tr>
			  
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["seven"]; ?>" onBlur="saveInlineEdit(this,'seven','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["seven"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["sevendate"]; ?>" onBlur="saveInlineEdit(this,'sevendate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["sevendate"]; ?></td>
				  
				  
			  </tr>
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["eight"]; ?>" onBlur="saveInlineEdit(this,'eight','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["eight"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["eightdate"]; ?>"  onBlur="saveInlineEdit(this,'eightdate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["eightdate"]; ?></td>
				  
				  
			  </tr>
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["nine"]; ?>" onBlur="saveInlineEdit(this,'nine','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["nine"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["ninedate"]; ?>"  onBlur="saveInlineEdit(this,'ninedate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["ninedate"]; ?></td>
				  
				  
			  </tr>
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $row["ten"]; ?>" onBlur="saveInlineEdit(this,'ten','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["ten"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $row["tendate"]; ?>"  onBlur="saveInlineEdit(this,'tendate','<?php echo $row["Application_No"]; ?>')" onClick="highlightEdit(this);"><?php echo $row["tendate"]; ?></td>
				  
				  
			  </tr>
          
          
		  
							 
											
							  
							
						  
				  
				  </tbody>
							</table>
        </div>
      </div>
    </div>
									<?php } }}?>
						
							  
							 
							</div>
						</div>
					  </div>
					  
					</div>
				  <br>
				  <br>
				  <!-- Modal -->
				  <div class="modal fade bs-example-modal-lg" id="newform" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">New Application</h4>
						  
                        </div>
                        <div class="modal-body">
						<p id="message"></p>
						<form id="insert_det">
							 <div class="form-group">
								<input type="hidden" name = "adhaar" id="adhaar">
								<label style="padding-left:100px;"><strong>Application No.:&nbsp;</strong></label>
								<input name="Application_No" id="Application_No" type="text" style="padding-bottom:6px;width:200px;" value="<?php echo $Application+1; ?>" readonly>
								
								<label style="padding-left:70px;"><strong>Date of transaction:&nbsp;</strong></label>
								<input type="text" value="<?php echo date("Y-m-d"); ?>"  name="Date_of_transaction" id="Date_of_transaction" style="padding-bottom:6px;width:128px;"> 
							 
							 </div>
							 <div class="form-group">
								<label style="margin-left:76px;padding-left:3px"><strong>Amount Required:&nbsp;</strong></label>
								<input id="Amount_Req" name="Amount_Req" type="text" style="padding-bottom:6px;width:200px;">
								
							
							</div>
							<div class="form-group">
								<div class="col">
								<label style="margin-left:76px;padding-left:3px"><strong>Weight Of Jewel:&nbsp;</strong></label>
								<input id="weight" name="weight" type="text" style="padding-bottom:6px;width:200px;">
								</div>
							</div>
							<div class="form-group">
							<br>
							<div class="col"><label style="margin-left:80px"><strong>Remarks: &nbsp;</strong></label><input name="Details" id="Details" type="textarea" style="padding-bottom:6px;width:580px;"></div>
							</div>
												
							  
						  
							<div class="modal-footer">
							  
						  <div >
							<div class="col-md-6 col-sm-6 col-xs-12">
							  <div>
							  <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
							  <button type="submit" class="btn btn-success" name="enter" id="enter">Submit</button>
							  </div>
							  
							</div>
						  </div>
					  </form>
                        </div>

                      </div>
                    </div>
                  </div>
				  <center>
				  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="edit">
					<div class="modal-dailog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
							<h3 class="text-dark">Edit Form</h3>
							
							</div>
							<div class="modal-body">
							
							<form id="insert_form">
							<label><strong>Application No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_App" readonly>
							<label><strong>Adhaar No.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Adhaar" readonly>
							<label><strong>Date of Transaction.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="dot" readonly>
							<label><strong>Amount Requested.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_AmountRequested" readonly>
							<label><strong>Amount Sanctioned.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_AmountSanctioned">
							<br>
							<label><strong>Discharge Report:&nbsp;</strong></label>
							<select id="Up_Discharge" name="Up_Discharge">
								<option ></option>
								<option value="submitted">Submitted</option>
								<option value="not submitted">Not Submitted</option></select>
								<br>
							<label><strong>Remarks.:&nbsp;</strong></label>
							<input type="text" class="form-control" placeholder="" id="Up_Details">
							
							</div>
							<div class="modal-footer">
							<input type="button" class="btn btn-success" value="Update" id="update"></button>
							<input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel" id="btn_close"></button>
							</div>
							</form>
						</div>		
					</div>
				</div>
				</center>
				
		
				  <!--Modalend-->
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Copyright ©  <a href="https://juntossoft.com">juntos software solution.</a> All rights reserved.
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
	<script src="functionloan.js"></script>
	
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- jQuery custom content scroller -->
    <script src="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- validator -->
    <script src="../vendors/validator/validator.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
