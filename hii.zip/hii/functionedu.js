$(document).ready(function()
{
	Insert_record();
	edit();
	update();
	get();
	app_edit();
	getUrlVars();
	$('#mop').on('change', function() {
      if ( this.value == 'cheque')
      {
        $("#myDIV").show();
      }
      else
      {
        $("#myDIV").hide();
      }
    });
	
	
	
})


function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=%20');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
     var ids = vars['id'];
	
	
	if(ids!=''){
		
		
			
			$.ajax(
				{
					url : 'get_edudetails.php',
					method : 'post',
					data :{ids:ids},
					dataType :"JSON",
					success:function(data){
					
						$('#Adhaarnumber').val(data.Adhaarnumber);
						$('#firstname').val(data.firstname);
						$('#lastname').val(data.lastname);
						$('#dateofbirth').val(data.dateofbirth);
						$('#Fathername').val(data.fathername);
						$('#number').val(data.mobilenumber);
						$('#address').val(data.addrss);
						$('#town').val(data.town);
						$('#adhaar').val(data.Adhaarnumber);
						$.ajax(
						{
							url : 'table_edu.php',
							method : 'post',
							data :{ids:ids},
							success:function(data){
								
								$('#table').html(data);
								
							}
						});
						
					}
					
			
		});
			
			
	
}
}
function get(){
	$(document).on('click','#go',function(){
		var ids =$('#input').val();
		
		if(ids != ''){
			$.ajax(
				{
					url : 'get_edudetails.php',
					method : 'post',
					data :{ids:ids},
					dataType :"JSON",
					success:function(data){
						$('#Adhaarnumber').val(data.Adhaarnumber);
						$('#firstname').val(data.firstname);
						$('#lastname').val(data.lastname);
						$('#dateofbirth').val(data.dateofbirth);
						$('#number').val(data.mobilenumber);
						$('#address').val(data.addrss);
						$('#town').val(data.town);
						$('#adhaar').val(data.Adhaarnumber);
						var Adhaarnumber = data.Adhaarnumber;
						window.open('educationalold.php?id= '+Adhaarnumber,'_self');
						$.ajax(
							{
								url : 'table_edu.php',
								method : 'post',
								data :{ids:ids},
								success:function(data){
									$('#table').html(data);
										
									
								}
							});
						
					}
					
			
		});
		
	}
});
}
function Insert_record()
{	
	$('#insert_det').submit(function(e)
	{
		e.preventDefault();
		var Adhaarnumber = $('#adhaar').val();
		var Application = $('#Application_No').val();
		var dateoftransaction = $('#Date_of_transaction').val();
		var courseduration = $('#course_dur').val();
		var institution = $('#Inst_appl').val();
		var course = $('#course_appl').val();
		var fees = $('#Fees').val();
		var marks = $('#Marks_obt').val();
		var last = $('#Last_studied').val();
		var remarks = $('#Details')	   
		
		if(Adhaarnumber== "" || Application == ""){
			alert("Check the data");
		
			
		}else if(courseduration == 2 ){
			$.ajax(
			{
				url : 'year2.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,App:Application,courseduration:courseduration,dateoftransaction:dateoftransaction,course:course,institution:institution,fees:fees,marks:marks,last:last},
			
				success:function(data){
					
									window.open('educationalold.php?id= '+Adhaarnumber,'_self');
									if (confirm('Inserted Successfully'+"\nDo you want to print?")) {
												  
												  window.open('educationalold.php?id='+Application);
												  
												  
										} else {
										  txt = "You pressed Cancel!";
										}
									$('insert_det')[0].reset();
									$('#newform').modal('hide');
				}
				
			});
			
			
		}else if(courseduration == 1 ){
			$.ajax(
			{
				url : 'year1.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,App:Application,courseduration:courseduration,dateoftransaction:dateoftransaction,course:course,institution:institution,fees:fees,marks:marks,last:last},
			
				success:function(data){
					
									window.open('educationalold.php?id= '+Adhaarnumber,'_self');
									if (confirm('Inserted Successfully'+"\nDo you want to print?")) {
												  
												  window.open('invoice-db.php?id='+Application);
												  
												  
										} else {
										  txt = "You pressed Cancel!";
										}
									$('insert_det')[0].reset();
									$('#newform').modal('hide');
									
									
									
								
						
				}
				
			});
			
			
		}else if(courseduration == 3 ){
			$.ajax(
			{
				url : 'year3.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,App:Application,courseduration:courseduration,dateoftransaction:dateoftransaction,course:course,institution:institution,fees:fees,marks:marks,last:last},
			
				success:function(data){
					
									window.open('educationalold.php?id= '+Adhaarnumber,'_self');
									if (confirm('Inserted Successfully'+"\nDo you want to print?")) {
												  
												  window.open('invoice-db.php?id='+Application);
												  
												  
										} else {
										  txt = "You pressed Cancel!";
										}
									$('insert_det')[0].reset();
									$('#newform').modal('hide');
									
									
									
							
						
				}
				
			});
			
			
		}else if(courseduration == 4 ){
			$.ajax(
			{
				url : 'year4.php',
				method : 'post',
				data :{Adhaar:Adhaarnumber,App:Application,courseduration:courseduration,dateoftransaction:dateoftransaction,course:course,institution:institution,fees:fees,marks:marks,last:last},
			
				success:function(data){
				
									window.open('educationalold.php?id= '+Adhaarnumber,'_self');
									if (confirm('Inserted Successfully'+"\nDo you want to print?")) {
												  
												  window.open('invoice-db.php?id='+Application);
												  
												  
										} else {
										  txt = "You pressed Cancel!";
										}
									$('insert_det')[0].reset();
									$('#newform').modal('hide');
									
									
									
								
						
				}
				
				
				
			});
			
			
		}
	});
}
function app_edit(){
	$(document).on('click','#new_app',function(){
		var adha=$('#Adhaarnumber').val();
		$.ajax(
			{
				url : "app_edudata.php",
				method : 'post',
				data : {adhaar:adha},
				dataType :"JSON",
				beforeSend:function(){  
							
                          $('#new_app').val("Updating");				  
                     },
				success:function(data){
					
					$('#Application_No').val(++data[0]);
					
					$('#newform').modal('show');
					
				}
				
		
		});
	});
}
function edit(){
	$(document).on('click','#editfrm',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App1').val(data.Application_No);
					$('#Up_fee1').val(data.Feesstruture);
					$('#dot1').val(data.dateofsanctioned);
					
					if(data.Courseduration==1){
						$('#Up_Amount1').val(data.Amountsanctioned);
					}
					$('#edit').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm21',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata21.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App2').val(data.Application_No);
					$('#Up_fee2').val(data.Fees_Structure);
					$('#dot2').val(data.dateofsanctioned);

					if(data.courseduration==2){
						$('#Up_Amount2').val((data.Fees_Structure*90)/200);
					}
					$('#edit1').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm22',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata21.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App21').val(data.Application_No);
					$('#Up_fee21').val(data.Fees_Structure);
					$('#dot21').val(data.dateofsanctioned2);
					$('#Up_Arrear21').val(data.arrears);
					if(data.courseduration==2){
						$('#Up_Amount21').val((data.Fees_Structure*90)/200);
					}
					$('#edit12').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm31',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata31.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App31').val(data.Application_No);
					$('#Up_fee31').val(data.Feesstruture);
					$('#dot31').val(data.dateofsanctioned);
					if(data.courseduration==3){
						$('#Up_Amount31').val((data.Feesstruture*90)/300);
					}
					$('#edit21').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm32',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata31.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App32').val(data.Application_No);
					$('#Up_fee32').val(data.Feesstruture);
					$('#dot32').val(data.dateofsanctioned1);
					$('#Up_Arrear32').val(data.arrears);
					if(data.courseduration==3){
						$('#Up_Amount32').val((data.Feesstruture*90)/300);
					}$('#edit22').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm33',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata31.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App33').val(data.Application_No);
					$('#Up_fee33').val(data.Feesstruture);
					$('#dot33').val(data.dateofsanctioned2);
					$('#Up_Arrear33').val(data.arrears1);
					if(data.courseduration==3){
						$('#Up_Amount33').val((data.Feesstruture*90)/300);
					}$('#edit23').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm41',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata41.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App41').val(data.Application_No);
					$('#Up_fee41').val(data.Feesstruture);
					$('#dot41').val(data.dateoftransaction);
					if(data.courseduration==4){
						$('#Up_Amount41').val((data.Feesstruture*90)/400);
					}$('#edit41').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm42',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata41.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App42').val(data.Application_No);
					$('#Up_fee42').val(data.Feesstruture);
					$('#dot42').val(data.dateoftransaction1);
					$('#Up_Arrear42').val(data.arrears);
					if(data.courseduration==4){
						$('#Up_Amount42').val((data.Feesstruture*90)/400);
					}$('#edit42').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm43',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata41.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App43').val(data.Application_No);
					$('#Up_fee43').val(data.Feesstruture);
					$('#dot43').val(data.dateoftransaction2);
					$('#Up_Arrear43').val(data.arrears1);
					if(data.courseduration==4){
						$('#Up_Amount43').val((data.Feesstruture*90)/400);
					}$('#edit43').modal('show');
					
				}
				
		
	});
});
$(document).on('click','#editfrm44',function(){
		var Appli=$(this).attr('data-id');
		$.ajax(
			{
				url : 'get_edudata41.php',
				method : 'post',
				data :{App:Appli},
				dataType :"JSON",
				success:function(data){
					$('#Up_App44').val(data.Application_No);
					$('#Up_fee44').val(data.Feesstruture);
					$('#dot44').val(data.dateoftransaction3);
					$('#Up_Arrear44').val(data.arrears2);
					if(data.courseduration==4){
						$('#Up_Amount44').val((data.Feesstruture*90)/400);
					}$('#edit44').modal('show');
					
				}
				
		
	});
});
}
function update(){
	$('#insert_form').submit(function(){  
				var file=$('#Up_marksheet1').val();		
                $.ajax({ 
					 url:'updateedu.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
                     beforeSend:function(){  
                          $('#update1').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  
	  $('#insert_form2').submit(function(){ 
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App2').val();
				var dateoftransaction = $('#dot2').val();
				var Marks = $('#Up_marks2').val();
				var amountsanctioned = $('#Up_Amount2').val();
							
                $.ajax({ 
					 url:'updateedu2.php',  
                     method:"post",
					 data:new FormData(this), 
					 contentType:false,
				     processData:false,
                     beforeSend:function(){  
                          $('#update21').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form2')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  
		$('#insert_form3').submit(function(){  
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App21').val();
				var dateoftransaction = $('#dot21').val();
				var Marks1 = $('#Up_marks21').val();
				var Arrears = $('#Up_Arrear21').val();
				var amountsanctioned = $('#Up_Amount21').val();
							
                $.ajax({ 
					 url:'updateedu3.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update22').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form3')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  $('#insert_form4').submit(function(){ 
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App31').val();
				var dateoftransaction = $('#dot31').val();
				var Marks = $('#Up_marks31').val();
				var amountsanctioned = $('#Up_Amount31').val();
							
                $.ajax({ 
					 url:'updateedu4.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update31').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form4')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	 $('#insert_form5').submit(function(){  
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App32').val();
				var dateoftransaction = $('#dot32').val();
				var Marks2 = $('#Up_marks32').val();
				var Arrears = $('#Up_Arrear32').val();
				var amountsanctioned = $('#Up_Amount32').val();
							
                $.ajax({ 
					 url:'updateedu5.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update32').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form5')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  $('#insert_form6').submit(function(){ 
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App33').val();
				var dateoftransaction = $('#dot33').val();
				var Marks3 = $('#Up_marks33').val();
				var Arrears1 = $('#Up_Arrear33').val();
				var amountsanctioned = $('#Up_Amount33').val();			
                $.ajax({ 
					 url:'updateedu6.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update33').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form6')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  $('#insert_form7').submit(function(){  
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App41').val();
				var dateoftransaction = $('#dot41').val();
				var Marks = $('#Up_marks41').val();
				var amountsanctioned = $('#Up_Amount41').val();
							
                $.ajax({ 
					 url:'updateedu7.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update41').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form7')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  $('#insert_form8').submit(function(){   
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App42').val();
				var dateoftransaction = $('#dot42').val();
				var Marks1 = $('#Up_marks42').val();
				var Arrears = $('#Up_Arrear42').val();
				var amountsanctioned = $('#Up_Amount42').val();
							
                $.ajax({ 
					 url:'updateedu8.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update42').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form8')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  $('#insert_form9').submit(function(){   
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App43').val();
				var dateoftransaction = $('#dot43').val();
				var Marks2 = $('#Up_marks43').val();
				var Arrears2 = $('#Up_Arrear43').val();
				var amountsanctioned = $('#Up_Amount43').val();
							
                $.ajax({ 
					 url:'updateedu9.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update43').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form9')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
	  $('#insert_form10').submit(function(){   
				
				var Adhaarnumber=$('#Adhaarnumber').val();
				var Application = $('#Up_App44').val();
				var dateoftransaction = $('#dot44').val();
				var Marks3 = $('#Up_marks44').val();
				var Arrears3 = $('#Up_Arrear44').val();
				var amountsanctioned = $('#Up_Amount44').val();
							
                $.ajax({ 
					 url:'updateedu10.php',  
                     method:"post",  
                     data:new FormData(this), 
					 contentType:false,
				     processData:false,
					 beforeSend:function(){  
                          $('#update44').val("Updating");  
                     },  
                     success:function(data){  
                          $('#insert_form10')[0].reset();  
                          $('#edit').modal('hide'); 
						  window.open('educationalold.php?id= '+Adhaarnumber,'_self');
                          alert(data);
					 } 
                });  
          
      });
}

