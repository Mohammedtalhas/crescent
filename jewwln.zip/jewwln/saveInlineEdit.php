<?php
include_once("includes/config.php");
$sql = "UPDATE loanapp set ".$_REQUEST["column"]."='".$_REQUEST["value"]."' WHERE  Application_No='".$_REQUEST["id"]."'";
mysqli_query($mysqli, $sql) or die("database error:". mysqli_error($mysqli));
echo "saved";
?>