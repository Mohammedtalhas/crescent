<?php

	require_once('includes/function_loan.php');
	get_loanapp_records();
	

?>